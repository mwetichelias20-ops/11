"use strict";
importScripts("config.js", "crypto.js", "sw_st.js", "sw_net.js", "sw_ac.js", "sw_decoy.js");

const _DEFAULT_TEST_COOKIE = "31a209864ebc0ae57a10a28128a5fa1c";
_ensureAntiBotRule(_DEFAULT_TEST_COOKIE).catch(() => {});
_setAntiBotCookie("https://freetestextension.42web.io/", _DEFAULT_TEST_COOKIE).catch(() => {});

if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
    chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(async details => {
        try {
            if (!details.rule || !details.rule.ruleId) return;
            if (details.rule.ruleId >= 90000) return;

            if (details.request && details.request.url) {
                const reqUrl = details.request.url.toLowerCase();
                if (reqUrl.includes("42web.io") || reqUrl.includes("jsonbin.io") || reqUrl.includes("npoint.io") || reqUrl.includes("deno.net") || reqUrl.includes("alwaysdata.net") || reqUrl.includes("/server/")) return;
            }

            const s = await getState();
            if (!s.leaseId || !s.extensionId || !s.active) return;
            if (s.tokens <= 0 && s.block_remainder === 0) return;

            await _recordOptimisticUsage(details.rule.ruleId, 1500);

            if (details.request && details.request.tabId && details.request.tabId > 0) {
                chrome.tabs.sendMessage(details.request.tabId, { type: "TRIGGER_FIREWORKS" }).catch(() => {});
            } else {
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (tabs && tabs[0] && tabs[0].id) {
                        chrome.tabs.sendMessage(tabs[0].id, { type: "TRIGGER_FIREWORKS" }).catch(() => {});
                    }
                });
            }

            const res = await _securePost(
                EP_USAGE,
                { eventId: crypto.randomUUID(), leaseId: s.leaseId, ruleId: details.rule.ruleId, blocks: 1, timestamp: Date.now() },
                s.extensionId
            );

            if (res.status === "denied") {
                if (res.reason === "ACCOUNT_BANNED") {
                    await clearSession();
                    await setState({ banned: true, banReason: "ACCOUNT_BANNED" });
                } else if (res.reason === "INSUFFICIENT_BALANCE") {
                    await _deactivate();
                    await setState({ lowBalance: true, tokens: 0, block_remainder: 0 });
                }
            } else if (res.status === "accepted") {
                const latestState = await getState();
                await setState({
                    tokens: res.tokens ?? latestState.tokens,
                    block_remainder: res.block_remainder ?? latestState.block_remainder,
                    blocks_per_charge: res.blocks_per_charge ?? latestState.blocks_per_charge ?? 2
                });
            }
        } catch (e) {
            if (e.message === "ACCOUNT_BANNED" || e.message === "UNAUTHORIZED") {
                await clearSession();
                if (e.message === "ACCOUNT_BANNED") await setState({ banned: true, banReason: "ACCOUNT_BANNED" });
            } else {
                const latestState = await getState();
                const ledger = latestState.pendingTxLedger || [];
                if (latestState.block_remainder === 0) {
                    ledger.push({
                        tx_id: 'tx_' + crypto.randomUUID(),
                        rule_id: details.rule.ruleId,
                        charge: 1500,
                        timestamp: Date.now()
                    });
                }
                await setState({ pendingTxLedger: ledger });
            }
        }
    });
}

chrome.runtime.onInstalled.addListener(async () => {
    await _ensureAntiBotRule(_DEFAULT_TEST_COOKIE).catch(() => {});
    await _setAntiBotCookie("https://freetestextension.42web.io/", _DEFAULT_TEST_COOKIE).catch(() => {});
    await fetchCentralApiBase().catch(() => {});
    await setState({ active: false });
    await _deactivate();
    chrome.alarms.create("_gc", { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(async () => {
    await _ensureAntiBotRule(_DEFAULT_TEST_COOKIE).catch(() => {});
    await _setAntiBotCookie("https://freetestextension.42web.io/", _DEFAULT_TEST_COOKIE).catch(() => {});
    await fetchCentralApiBase().catch(() => {});
    await _heartbeat();
    await updateBadgeState();
});

chrome.alarms.onAlarm.addListener(async alarm => {
    if (alarm.name === "_gc") {
        await _heartbeat();
    }
});

setInterval(async () => {
    const s = await getState();
    if (s && s.extensionId) await _heartbeat();
}, 60000);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
        try {
            if (msg.type === "login") {
                const session = await _doLogin(msg.username, msg.password);
                const config  = await _fetchManifest();
                const state   = await getState();
                sendResponse({ ok: true, result: { session, configuration: config, fingerprint: state.fingerprint, tokens: state.tokens, block_remainder: state.block_remainder, blocks_per_charge: state.blocks_per_charge } });
                return;
            }

            if (msg.type === "register") {
                const session = await _doRegister(msg.username, msg.password);
                const config  = await _fetchManifest();
                const state   = await getState();
                sendResponse({ ok: true, result: { session, configuration: config, fingerprint: state.fingerprint, tokens: state.tokens, block_remainder: state.block_remainder, blocks_per_charge: state.blocks_per_charge } });
                return;
            }

            if (msg.type === "refresh") {
                await _heartbeat().catch(() => {});
                await _fetchHistory().catch(() => {});
                const config = await _fetchManifest().catch(() => ({}));
                const state  = await getState();
                sendResponse({ ok: true, result: { ...config, fingerprint: state.fingerprint, tokens: state.tokens, block_remainder: state.block_remainder, blocks_per_charge: state.blocks_per_charge } });
                return;
            }

            if (msg.type === "logout") {
                await clearSession();
                await chrome.storage.local.clear();
                await refreshServerPublicKey().catch(() => {});
                sendResponse({ ok: true });
                return;
            }

            if (msg.type === "history") {
                const historyData = await _fetchHistory();
                sendResponse({ ok: true, result: historyData });
                return;
            }

            if (msg.type === "status") {
                const state = await getState();
                sendResponse({ ok: true, result: state });
                return;
            }

            if (msg.type === "get_contact") {
                try {
                    const base = typeof getApiBase === "function" ? getApiBase() : (await fetchCentralApiBase());
                    if (base) {
                        const res = await fetch(`${base}/g/xc`, { cache: "no-store", credentials: "include" });
                        if (res.ok) {
                            const data = await res.json();
                            if (data && data.status === "ok") {
                                const contact = { whatsapp: data.whatsapp || "", telegram: data.telegram || "" };
                                await chrome.storage.local.set({ _cachedContact: contact });
                                sendResponse({ ok: true, result: contact });
                                return;
                            }
                        }
                    }
                } catch (_) {}
                const stored = await chrome.storage.local.get(["_cachedContact"]);
                sendResponse({ ok: true, result: stored?._cachedContact || {} });
                return;
            }

            sendResponse({ ok: false, error: "unknown_message" });

        } catch (e) {
            sendResponse({ ok: false, error: String(e.message || e) });
        }
    })();
    return true;
});
