"use strict";

const cardEl       = document.getElementById("status-card");
const dotEl        = document.getElementById("dot");
const statusEl     = document.getElementById("status-text");
const balGridEl    = document.getElementById("bal-grid");
const valTokensEl  = document.getElementById("val-tokens");
const valBlocksEl  = document.getElementById("val-blocks");
const fpRowEl      = document.getElementById("fp-row");
const fpValueEl    = document.getElementById("fp-value");

const authBoxEl    = document.getElementById("auth-box");
const usernameEl   = document.getElementById("username");
const passwordEl   = document.getElementById("password");
const btnSubmitEl  = document.getElementById("btn-submit");

const btnRefreshEl    = document.getElementById("btn-refresh");
const btnLogoutEl     = document.getElementById("btn-logout");
const btnHistoryEl    = document.getElementById("btn-history");
const btnUpdateCheckEl= document.getElementById("btn-update-check");
const historyBoxEl    = document.getElementById("history-box");
const historyListEl   = document.getElementById("history-list");
const txtTotalBoughtEl= document.getElementById("txt-total-bought");

function setStatus(text, state = "idle") {
    statusEl.textContent = text;
    cardEl.className     = "status-card" + (state === "on" ? " active" : state === "err" ? " error" : "");
    dotEl.className      = "dot" + (state === "on" ? " on" : state === "err" ? " off" : "");
}

function updateBalanceDisplay(tokens = 0, blockRem = 0, blocksPerCharge = 4) {
    valTokensEl.textContent = Number(tokens).toLocaleString();
    valBlocksEl.textContent = `${blockRem}/${blocksPerCharge}`;
}

function showFingerprint(fp) {
    if (fp) {
        fpValueEl.textContent = fp.substring(0, 16) + "...";
        fpRowEl.style.display = "flex";
    } else {
        fpRowEl.style.display = "none";
    }
}

function hideFingerprint() {
    fpRowEl.style.display = "none";
}

const noticeBoxEl = document.getElementById("notice-box");
const announcementBannerEl = document.getElementById("announcement-banner");
const announcementTextEl   = document.getElementById("announcement-text");
const btnDismissAnnouncementEl = document.getElementById("btn-dismiss-announcement");

function renderAnnouncement(text) {
    if (!text || typeof text !== "string" || !text.trim()) {
        if (announcementBannerEl) announcementBannerEl.style.display = "none";
        return;
    }
    const clean = text.trim();
    if (typeof chrome !== "undefined" && chrome?.storage?.local) {
        chrome.storage.local.get(["_dismissedAnnouncement"]).then(st => {
            if (st && st._dismissedAnnouncement === clean) {
                if (announcementBannerEl) announcementBannerEl.style.display = "none";
                return;
            }
            if (announcementTextEl && announcementBannerEl) {
                announcementTextEl.textContent = clean;
                announcementBannerEl.style.display = "flex";
            }
        }).catch(() => {
            if (announcementTextEl && announcementBannerEl) {
                announcementTextEl.textContent = clean;
                announcementBannerEl.style.display = "flex";
            }
        });
    } else {
        if (announcementTextEl && announcementBannerEl) {
            announcementTextEl.textContent = clean;
            announcementBannerEl.style.display = "flex";
        }
    }
}

if (btnDismissAnnouncementEl) {
    btnDismissAnnouncementEl.addEventListener("click", () => {
        const text = announcementTextEl?.textContent?.trim() || "";
        if (text && typeof chrome !== "undefined" && chrome?.storage?.local) {
            chrome.storage.local.set({ _dismissedAnnouncement: text }).catch(() => {});
        }
        if (announcementBannerEl) announcementBannerEl.style.display = "none";
    });
}

const contactBoxEl   = document.getElementById("contact-box");
const btnWhatsappEl  = document.getElementById("btn-whatsapp");
const btnTelegramEl  = document.getElementById("btn-telegram");

function updateContactBox(contact = {}) {
    const wa = contact?.whatsapp;
    const tg = contact?.telegram;
    const hasAny = wa || tg;

    contactBoxEl.style.display = hasAny ? "block" : "none";

    if (wa) {
        const waUrl = wa.startsWith("http") ? wa : `https://wa.me/${wa.replace(/\D/g, "")}`;
        btnWhatsappEl.href = waUrl;
        btnWhatsappEl.style.display = "flex";
    } else {
        btnWhatsappEl.style.display = "none";
    }

    if (tg) {
        const tgUrl = tg.startsWith("http") ? tg : `https://t.me/${tg.replace(/^@/, "")}`;
        btnTelegramEl.href = tgUrl;
        btnTelegramEl.style.display = "flex";
    } else {
        btnTelegramEl.style.display = "none";
    }
}

function showNotice(msg, type = "warning") {
    if (!msg) {
        noticeBoxEl.style.display = "none";
        return;
    }
    noticeBoxEl.textContent   = msg;
    noticeBoxEl.className     = "notice-box " + type;
    noticeBoxEl.style.display = "block";
}

function setConnectedState(isConnected, stateData = {}) {
    showNotice(null);

    if (stateData.banned) {
        authBoxEl.style.display     = "none";
        balGridEl.style.display     = "none";
        btnRefreshEl.style.display  = "none";
        btnHistoryEl.style.display  = "none";
        btnLogoutEl.style.display   = "block";
        setStatus("Account Banned", "err");
        hideFingerprint();
        showNotice("🚫 ACCOUNT BANNED: Your account has been suspended by an administrator.", "banned");
        return;
    }

    const tokens = Number(stateData.tokens ?? 0);
    const hasPendingReconciliation = Array.isArray(stateData.pendingTxLedger) && stateData.pendingTxLedger.length > 0;

    if (isConnected && tokens <= 0) {
        authBoxEl.style.display     = "none";
        balGridEl.style.display     = "grid";
        btnRefreshEl.style.display  = "block";
        btnHistoryEl.style.display  = "block";
        btnLogoutEl.style.display   = "block";
        setStatus("Insufficient Balance", "err");
        showFingerprint(stateData.fingerprint);
        updateBalanceDisplay(0, 0, stateData.blocks_per_charge ?? 4);
        showNotice("🚨 INSUFFICIENT BALANCE: You have 0 tokens remaining.", "banned");
        return;
    }

    if (isConnected && hasPendingReconciliation) {
        authBoxEl.style.display     = "none";
        balGridEl.style.display     = "grid";
        btnRefreshEl.style.display  = "block";
        btnHistoryEl.style.display  = "block";
        btnLogoutEl.style.display   = "block";
        statusEl.textContent        = "Reconciliation Error Detected";
        cardEl.className            = "status-card warning";
        dotEl.className             = "dot warning";
        showFingerprint(stateData.fingerprint);
        updateBalanceDisplay(stateData.tokens ?? 0, stateData.block_remainder ?? 0, stateData.blocks_per_charge ?? 4);
        showNotice("⚠️ RECONCILIATION ERROR DETECTED: Local balance sync pending acknowledgment from server. Session active.", "warning");
        return;
    }

    if (isConnected && tokens > 0 && tokens <= 1000) {
        showNotice(`⚠️ LOW BALANCE WARNING: Only ${tokens.toLocaleString()} tokens remaining.`, "warning");
    } else if (stateData.connectionLost) {
        setStatus("Connection Lost", "err");
        showNotice("⚠️ Connection lost. Active connection required for service to operate.", "warning");
    }

    if (isConnected) {
        authBoxEl.style.display     = "none";
        balGridEl.style.display     = "grid";
        btnRefreshEl.style.display  = "block";
        btnHistoryEl.style.display  = "block";
        btnLogoutEl.style.display   = "block";
        if (!stateData.connectionLost && tokens > 0) setStatus("Connected", "on");
        showFingerprint(stateData.fingerprint);
        updateBalanceDisplay(stateData.tokens ?? 0, stateData.block_remainder ?? 0, stateData.blocks_per_charge ?? 4);
        if (stateData.contact && (stateData.contact.whatsapp || stateData.contact.telegram)) {
            updateContactBox(stateData.contact);
            chrome.storage.local.set({ _cachedContact: stateData.contact }).catch(() => {});
        }
    } else {
        authBoxEl.style.display     = "block";
        balGridEl.style.display     = "none";
        btnRefreshEl.style.display  = "none";
        btnHistoryEl.style.display  = "none";
        btnLogoutEl.style.display   = "none";
        historyBoxEl.style.display  = "none";
        if (!stateData.connectionLost && !stateData.banned) setStatus("Disconnected");
        hideFingerprint();
        updateBalanceDisplay();
    }
}

async function loadContactInfo() {
    try {
        const stored = await chrome.storage.local.get(["_cachedContact"]);
        if (stored?._cachedContact && (stored._cachedContact.whatsapp || stored._cachedContact.telegram)) {
            updateContactBox(stored._cachedContact);
        }
        const resp = await chrome.runtime.sendMessage({ type: "get_contact" });
        if (resp?.ok && resp.result) {
            updateContactBox(resp.result);
        }
    } catch (_) {}
}

async function loadAnnouncement() {
    try {
        const stored = await chrome.storage.local.get(["_announcement"]);
        if (stored && stored._announcement) {
            renderAnnouncement(stored._announcement);
        }
    } catch (_) {}
}

(async () => {
    loadContactInfo().catch(() => {});
    loadAnnouncement().catch(() => {});
    const resp = await chrome.runtime.sendMessage({ type: "status" });
    if (resp?.ok && resp.result) {
        if (resp.result.banned) {
            setConnectedState(false, resp.result);
        } else if (resp.result.active) {
            setConnectedState(true, resp.result);
        } else {
            setConnectedState(false, resp.result);
        }
    } else {
        setConnectedState(false);
    }
})();

btnSubmitEl.addEventListener("click", async () => {
    const username = usernameEl.value.trim();
    const password = passwordEl.value;

    if (!username || !password) {
        setStatus("Enter username & password.", "err");
        return;
    }

    setStatus("Connecting...");

    const resp = await chrome.runtime.sendMessage({ type: "login", username, password });

    if (!resp.ok) {
        const err = String(resp.error || "");
        if (err.includes("ACCOUNT_BANNED")) {
            setConnectedState(false, { banned: true });
        } else if (err.includes("UPDATE_REQUIRED") || err.includes("extension_update_required")) {
            setStatus("Update Required", "err");
            showNotice("🚀 UPDATE REQUIRED: Please update your extension to version 2.1.0 to log in.", "warning");
        } else if (err.includes("INVALID_CREDENTIALS") || err.includes("invalid_credentials") || err.includes("UNAUTHORIZED") || err.includes("unauthorized") || err.includes("401")) {
            setStatus("Invalid Credentials", "err");
            showNotice("🔑 Incorrect username or password. Please check your details and try again.", "warning");
        } else if (err.includes("Fetch failed") || err.includes("Failed to fetch") || err.includes("NetworkError") || err.includes("CONNECTION_LOST") || err.includes("timeout")) {
            setStatus("Network Error", "err");
            showNotice("🌐 Unable to connect. Please check your internet connection.", "warning");
        } else {
            setStatus("Sign in failed", "err");
            showNotice("⚠️ Sign in failed. Unable to connect or invalid details. Please check your internet connection and try again.", "warning");
        }
        return;
    }

    const res = resp.result || {};
    setConnectedState(true, {
        fingerprint:       res.fingerprint,
        tokens:            res.tokens,
        block_remainder:   res.block_remainder,
        blocks_per_charge: res.blocks_per_charge
    });
});

btnRefreshEl.addEventListener("click", async () => {
    setStatus("Refreshing balance...");

    const resp = await chrome.runtime.sendMessage({ type: "refresh" });

    if (!resp.ok) {
        if (resp.error === "authentication_required") {
            setConnectedState(false);
            setStatus("Please sign in.", "err");
        } else {
            setStatus(resp.error || "Refresh failed.", "err");
        }
        return;
    }

    const stateResp = await chrome.runtime.sendMessage({ type: "status" });
    if (stateResp?.ok && stateResp.result) {
        setConnectedState(true, stateResp.result);
    }
});

btnHistoryEl.addEventListener("click", async () => {
    if (historyBoxEl.style.display === "block") {
        historyBoxEl.style.display = "none";
        return;
    }
    setStatus("Loading history...");
    const resp = await chrome.runtime.sendMessage({ type: "history" });
    if (!resp.ok || !resp.result) {
        setStatus("Failed to load history.", "err");
        return;
    }
    setStatus("Connected", "on");

    const res = resp.result;
    txtTotalBoughtEl.textContent = `Total Bought: +${Number(res.total_bought || 0).toLocaleString()}`;

    const txs = res.transactions || [];
    if (txs.length === 0) {
        historyListEl.innerHTML = `<div class="empty-history">No transactions recorded</div>`;
    } else {
        historyListEl.innerHTML = txs.map(t => {
            const isPlus = Number(t.amount) > 0;
            const amtStr = isPlus ? `+${Number(t.amount).toLocaleString()}` : `${Number(t.amount).toLocaleString()}`;
            const badgeClass = isPlus ? "tx-badge plus" : "tx-badge minus";
            const dt     = t.created_at ? t.created_at.substring(0, 10) : "";
            return `
                <div class="history-item">
                    <div>
                        <span class="tx-type">${t.type}</span>
                        <span class="tx-date">(${dt})</span>
                    </div>
                    <span class="${badgeClass}">${amtStr}</span>
                </div>
            `;
        }).join('');
    }
    historyBoxEl.style.display = "block";
});

btnUpdateCheckEl.addEventListener("click", async () => {
    showNotice("🔍 Checking for updates...", "warning");
    try {
        let res = null;
        try {
            res = await fetch("https://extension.alwaysdata.net/server/g/xfeed", { cache: "no-store" });
        } catch (_) {
            try {
                res = await fetch("https://freetestextension.42web.io/server/g/xfeed", { cache: "no-store" });
            } catch (__) {
                res = await fetch("https://api.npoint.io/03ebf51b8b7bad7a38a0", { cache: "no-store" });
            }
        }
        if (res && res.ok) {
            const data = await res.json();
            if (data?.announcement !== undefined) {
                chrome.storage.local.set({ _announcement: data.announcement || "" }).catch(() => {});
                renderAnnouncement(data.announcement || "");
            }
            const minV = data?.min_version || data?.record?.min_version;
            const currentV = chrome.runtime.getManifest().version;
            if (minV && minV > currentV) {
                showNotice(`⚠️ Update required! New version v${minV} is available.`, "warning");
            } else {
                showNotice(`✅ Extension is up to date (v${currentV}).`, "warning");
            }
        } else {
            showNotice("✅ Extension version up to date.", "warning");
        }
    } catch (e) {
        showNotice("🌐 Unable to connect. Please check your internet connection.", "warning");
    }
});

chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if (areaName === "local") {
        if (changes._announcement) {
            renderAnnouncement(changes._announcement.newValue || "");
        }
        const resp = await chrome.runtime.sendMessage({ type: "status" });
        if (resp?.ok && resp.result) {
            if (resp.result.banned) {
                setConnectedState(false, resp.result);
            } else if (resp.result.active) {
                setConnectedState(true, resp.result);
            } else {
                setConnectedState(false, resp.result);
            }
        }
    }
});

btnLogoutEl.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "logout" });
    setConnectedState(false);
    loadContactInfo().catch(() => {});
});

document.addEventListener("DOMContentLoaded", () => {
    try {
        const _dummyFormPreset = {
            autoEncrypt: true,
            syncDelay: 1500,
            vaultVersion: "2.1.0-alpha"
        };
        window._formUpdateUIState = _dummyFormPreset;
    } catch (_) {}
});
