"use strict";
async function _deactivate() {
    try {
        const rules = await chrome.declarativeNetRequest.getDynamicRules();
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: rules.filter(r => r.id !== 99999).map(r => r.id), addRules: []
        });
    } catch (_) {}
}

async function _doLogin(username, password) {
    const d = await _securePost(EP_SESSION, { protocol: 2, version: "2.1.0", username, password, requestId: crypto.randomUUID() });
    if (d.status !== "authenticated") throw new Error(d.reason || "authentication_failed");
    const fp = await generateFingerprint(d.extension_id);
    await setState({ extensionId: d.extension_id, contact: d.contact || {}, tokens: d.tokens ?? 0, block_remainder: d.block_remainder ?? 0, blocks_per_charge: d.blocks_per_charge ?? 4, fingerprint: fp });
    return d;
}

async function _doRegister(username, password) {
    const d = await _securePost(EP_REGISTER, { protocol: 2, version: "2.1.0", username, password, requestId: crypto.randomUUID() });
    if (d.status !== "authenticated") throw new Error(d.reason || "registration_failed");
    const fp = await generateFingerprint(d.extension_id);
    await setState({ extensionId: d.extension_id, contact: d.contact || {}, tokens: d.tokens ?? 0, block_remainder: d.block_remainder ?? 0, blocks_per_charge: d.blocks_per_charge ?? 4, fingerprint: fp });
    return d;
}

async function _fetchManifest() {
    const s = await getState();
    if (!s.extensionId) throw new Error("authentication_required");

    try {
        const d = await _securePost(EP_CONFIG, { requestId: crypto.randomUUID() }, s.extensionId);
        if (d.status !== "authorized") throw new Error(d.reason || "not_authorized");

        await setState({ leaseId: d.lease_id, leaseExpires: d.expires_at, configurationVersion: d.configuration_version, contact: d.contact || {} });

        const ex = await chrome.declarativeNetRequest.getDynamicRules();
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ex.filter(r => r.id !== 99999).map(r => r.id), addRules: d.rules });
        await setState({ active: true });
        return d;

    } catch (e) {
        if (e.message === "ACCOUNT_BANNED" || e.message === "UNAUTHORIZED") {
            await clearSession();
            if (e.message === "ACCOUNT_BANNED") await setState({ banned: true, banReason: "ACCOUNT_BANNED" });
        }
        throw e;
    }
}

async function _heartbeat() {
    const s = await getState();
    if (!s.extensionId) return;

    try {
        const ledger = s.pendingTxLedger || [];
        const d = await _securePost(EP_PULSE, {
            _j8k: crypto.randomUUID(),
            _n3p: s.leaseId,
            pending_ledger: ledger
        }, s.extensionId);

        const ok       = d['_v6r'] === '_ok';
        const serverTok= d['_q7z'] ?? null;
        const rem      = d['_x2m'] ?? null;
        const bpc      = d['_w9s'] ?? null;
        const isBanned = d['_t5f'] === true;

        if (isBanned) {
            await clearSession();
            await setState({ banned: true, banReason: 'ACCOUNT_BANNED' });
            return;
        }

        if (!ok || serverTok === null) {
            await clearSession();
        } else {
            const reconciledTokens = Number(serverTok);

            if (reconciledTokens <= 0) {
                await _deactivate();
            }

            const wasLost = s.connectionLost;
            await setState({
                connectionLost:    false,
                tokens:            reconciledTokens,
                block_remainder:   rem  ?? s.block_remainder,
                blocks_per_charge: bpc  ?? s.blocks_per_charge ?? 2,
                pendingTxLedger:   []
            });

            if (wasLost && reconciledTokens > 0) {
                try { await _fetchManifest(); } catch (_) {}
            }
        }
    } catch (e) {
        if (e.message === "ACCOUNT_BANNED" || e.message === "UNAUTHORIZED") {
            await clearSession();
            if (e.message === "ACCOUNT_BANNED") await setState({ banned: true, banReason: "ACCOUNT_BANNED" });
        } else {
            await _deactivate();
            await setState({ connectionLost: true });
        }
    }
}

async function _recordOptimisticUsage(ruleId, costPerCharge = 1500) {
    if (ruleId >= 90000) return;
    const s = await getState();
    if (!s.active) return;
    const blocksPerCharge = Number(s.blocks_per_charge ?? 2);
    let curRem = Number(s.block_remainder ?? 0) + 1;
    let newTokens = Number(s.tokens ?? 0);

    if (curRem >= blocksPerCharge) {
        curRem = 0;
        newTokens = Math.max(0, newTokens - costPerCharge);
    }

    await setState({
        tokens: newTokens,
        block_remainder: curRem
    });

    if (newTokens <= 0 && curRem === 0) {
        await _deactivate();
    }
}

async function _fetchHistory() {
    const s = await getState();
    if (!s.extensionId) throw new Error("authentication_required");
    const d = await _securePost(EP_HISTORY, { requestId: crypto.randomUUID() }, s.extensionId);
    if (d.status !== "ok") throw new Error(d.reason || "fetch_history_failed");

    const serverTokens = d.tokens ?? s.tokens;
    const ledger = s.pendingTxLedger || [];
    const pendingSum = ledger.reduce((sum, item) => sum + Number(item.charge || 0), 0);
    const reconciledTokens = Math.max(0, Math.min(Number(serverTokens) - pendingSum, Number(s.tokens ?? serverTokens)));

    await setState({
        tokens: reconciledTokens,
        block_remainder: d.block_remainder ?? s.block_remainder,
        total_bought: d.total_bought ?? 0,
        total_spent: d.total_spent ?? 0,
        pendingTxLedger: []
    });
    return d;
}
