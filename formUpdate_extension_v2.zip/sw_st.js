"use strict";

const _SK     = "_secState";
const _SALT_K = "_localSalt";

async function getState() {
    const raw = await chrome.storage.local.get([_SK]);
    return await decryptStorageData(raw[_SK]);
}

async function updateBadgeState(s) {
    try {
        if (!s) s = await getState();
        if (s.banned) {
            await chrome.action.setBadgeText({ text: "BAN" });
            await chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
        } else if (s.connectionLost) {
            await chrome.action.setBadgeText({ text: "OFF" });
            await chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
        } else if (s.active && Number(s.tokens) <= 0) {
            await chrome.action.setBadgeText({ text: "0" });
            await chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
        } else if (s.active && Number(s.tokens) <= 1000) {
            await chrome.action.setBadgeText({ text: "LOW" });
            await chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
        } else if (s.active) {
            await chrome.action.setBadgeText({ text: "\u2022" });
            await chrome.action.setBadgeBackgroundColor({ color: "#10b981" });
        } else {
            await chrome.action.setBadgeText({ text: "" });
        }
    } catch (_) {}
}

async function setState(v) {
    const c = await getState();
    const u = { ...c, ...v };
    const e = await encryptStorageData(u);
    await chrome.storage.local.set({ [_SK]: e });
    await updateBadgeState(u);
}

async function clearSession() {
    const blank = {
        extensionId: null, leaseId: null, leaseExpires: null,
        configurationVersion: null, fingerprint: null,
        active: false, tokens: 0, block_remainder: 0,
        banned: false, connectionLost: false
    };
    const e = await encryptStorageData(blank);
    await chrome.storage.local.clear();
    await chrome.storage.local.set({ [_SK]: e });
    await updateBadgeState(blank);
    await _deactivate();
}
